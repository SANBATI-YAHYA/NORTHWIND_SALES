import dash
from dash import dcc, html, Input, Output
import pandas as pd
import plotly.express as px

# Load dataset
df = pd.read_csv("C:\Users\sanba\Desktop\Me\cmc\PROJET\TNew folder\use_talend\DIM\FAIT.csv", sep=";",
                 encoding="ISO-8859-15")
# Ensure correct datetime format
df['order_date'] = pd.to_datetime(df['order_date'], format='%Y-%m-%d', errors='coerce')
df['shipped_date'] = pd.to_datetime(df['shipped_date'], format='%Y-%m-%d', errors='coerce')

# Ensure numeric columns
numeric_columns = ['total_price_dollar', 'discount_percent', 'order_quantity']
for col in numeric_columns:
    df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0)

# Calculate KPIs
total_sales = df['total_price_dollar'].sum()
total_orders = len(df['order_id'].unique())
avg_order_value = total_sales / total_orders if total_orders else 0

# Initialize Dash app
app = dash.Dash(__name__)

# Define app layout
app.layout = html.Div([
    # Title
    html.H1("📊 Business Performance Dashboard", style={'textAlign': 'center', 'color': '#00FF00'}),

    # KPI Cards
    html.Div([
        html.Div([
            html.H3("💰 Total Sales", style={'color': '#00FF00'}),
            html.P(f"${total_sales:,.2f}", style={'fontSize': '24px', 'color': '#00FF00'})
        ], className="kpi"),
        html.Div([
            html.H3("📦 Total Orders", style={'color': '#00FF00'}),
            html.P(f"{total_orders}", style={'fontSize': '24px', 'color': '#00FF00'})
        ], className="kpi"),
        html.Div([
            html.H3("💵 Avg Order Value", style={'color': '#00FF00'}),
            html.P(f"${avg_order_value:,.2f}", style={'fontSize': '24px', 'color': '#00FF00'})
        ], className="kpi"),
    ], className="kpi-container", style={'display': 'flex', 'justifyContent': 'space-around', 'marginBottom': '20px'}),

    # Date Picker
    html.Label("📅 Select Date Range:", style={'color': '#00FF00'}),
    dcc.DatePickerRange(
        id='date-picker',
        start_date=df['order_date'].min(),
        end_date=df['order_date'].max(),
        display_format='YYYY-MM-DD',
        style={'color': '#000000', 'backgroundColor': '#00FF00'}
    ),

    # Graphs
    html.Div([
        # First Row: Sales Trend and Discount Impact
        html.Div([
            dcc.Graph(id='sales-trend', style={'width': '48%', 'display': 'inline-block'}),
            dcc.Graph(id='discount-impact', style={'width': '48%', 'display': 'inline-block'})
        ], style={'marginTop': '20px'}),

        # Second Row: Product Demand and Sales by Region
        html.Div([
            dcc.Graph(id='product-demand', style={'width': '48%', 'display': 'inline-block'}),
            dcc.Graph(id='sales-by-region', style={'width': '48%', 'display': 'inline-block'})
        ], style={'marginTop': '20px'}),

        # Third Row: Customer Segmentation and Profit Margin
        html.Div([
            dcc.Graph(id='customer-segmentation', style={'width': '48%', 'display': 'inline-block'}),
            dcc.Graph(id='profit-margin', style={'width': '48%', 'display': 'inline-block'})
        ], style={'marginTop': '20px'}),

        # Fourth Row: Additional Visualizations
        html.Div([
            dcc.Graph(id='sales-by-category', style={'width': '48%', 'display': 'inline-block'}),
            dcc.Graph(id='order-quantity-trend', style={'width': '48%', 'display': 'inline-block'})
        ], style={'marginTop': '20px'})
    ])
], style={'backgroundColor': '#121212', 'color': 'white', 'padding': '20px'})

# Callbacks for updating graphs
@app.callback(
    [Output('sales-trend', 'figure'),
     Output('discount-impact', 'figure'),
     Output('product-demand', 'figure'),
     Output('sales-by-region', 'figure'),
     Output('customer-segmentation', 'figure'),
     Output('profit-margin', 'figure'),
     Output('sales-by-category', 'figure'),
     Output('order-quantity-trend', 'figure')],
    [Input('date-picker', 'start_date'), Input('date-picker', 'end_date')]
)
def update_graphs(start_date, end_date):
    start_date = pd.to_datetime(start_date)
    end_date = pd.to_datetime(end_date)
    filtered_df = df[(df['order_date'] >= start_date) & (df['order_date'] <= end_date)].copy()

    if filtered_df.empty:
        return [{}] * 8  # Return empty figures to prevent errors

    # Sales Trend Graph
    sales_trend = filtered_df.groupby('order_date')['total_price_dollar'].sum().reset_index()
    fig_sales_trend = px.line(sales_trend, x='order_date', y='total_price_dollar', title='📈 Sales Over Time',
                              template="plotly_dark", color_discrete_sequence=['#00FF00'])

    # Discount Impact
    fig_discount_impact = px.scatter(filtered_df, x='discount_percent', y='total_price_dollar', title='💲 Discount vs Revenue',
                                     template="plotly_dark", color_discrete_sequence=['#00FF00'])

    # Product Demand
    product_demand = filtered_df.groupby('product_name')['order_quantity'].sum().nlargest(10).reset_index()
    fig_product_demand = px.bar(product_demand, x='product_name', y='order_quantity',
                                title='🔥 Top 10 Most Ordered Products', template="plotly_dark", color_discrete_sequence=['#00FF00'])

    # Sales by Region
    if 'customer_region' in filtered_df.columns and not filtered_df['customer_region'].isnull().all():
        sales_by_region = filtered_df.groupby('customer_region')['total_price_dollar'].sum().reset_index()
        fig_sales_by_region = px.bar(sales_by_region, x='customer_region', y='total_price_dollar',
                                     title='🌍 Sales by Region', template="plotly_dark", color_discrete_sequence=['#00FF00'])
    else:
        fig_sales_by_region = {}

    # Customer Segmentation
    if 'customer_country' in filtered_df.columns and not filtered_df['customer_country'].isnull().all():
        customer_segmentation = filtered_df.groupby('customer_country')['total_price_dollar'].sum().reset_index()
        fig_customer_segmentation = px.pie(customer_segmentation, names='customer_country', values='total_price_dollar',
                                           title='🛒 Customer Segmentation', template="plotly_dark", color_discrete_sequence=px.colors.sequential.Greens)
    else:
        fig_customer_segmentation = {}

    # Profit Margin Analysis
    filtered_df['profit_margin'] = filtered_df['total_price_dollar'] - (filtered_df['total_price_dollar'] * (filtered_df['discount_percent'] / 100))
    fig_profit_margin = px.histogram(filtered_df, x='profit_margin', title='📊 Profit Margin Distribution',
                                     template="plotly_dark", color_discrete_sequence=['#00FF00'])

    # Sales by Product Category
    if 'category_name' in filtered_df.columns and not filtered_df['category_name'].isnull().all():
        sales_by_category = filtered_df.groupby('category_name')['total_price_dollar'].sum().reset_index()
        fig_sales_by_category = px.bar(sales_by_category, x='category_name', y='total_price_dollar',
                                       title='📦 Sales by Product Category', template="plotly_dark", color_discrete_sequence=['#00FF00'])
    else:
        fig_sales_by_category = {}

    # Order Quantity Trend
    order_quantity_trend = filtered_df.groupby('order_date')['order_quantity'].sum().reset_index()
    fig_order_quantity_trend = px.line(order_quantity_trend, x='order_date', y='order_quantity',
                                       title='📦 Order Quantity Over Time', template="plotly_dark", color_discrete_sequence=['#00FF00'])

    return fig_sales_trend, fig_discount_impact, fig_product_demand, fig_sales_by_region, fig_customer_segmentation, fig_profit_margin, fig_sales_by_category, fig_order_quantity_trend

# Run the app
if __name__ == '__main__':
    app.run_server(debug=True)